package com.example.springbootvazifa1.service;

import com.example.springbootvazifa1.entity.Xodim;
import com.example.springbootvazifa1.repository.BoshqaruvRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BoshqaruvService {
    private final BoshqaruvRepository boshqaruvReepository;

    public BoshqaruvService(BoshqaruvRepository boshqaruvReepository) {
        this.boshqaruvReepository = boshqaruvReepository;
    }
    public Xodim save(Xodim xodim){
      return boshqaruvReepository.save(xodim);
    }

    public ResponseEntity<Xodim> findById(Long id) {
        Optional<Xodim> byId = boshqaruvReepository.findById(id);
        if (byId.isPresent()) {
            return ResponseEntity.ok(byId.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    public ResponseEntity<List<Xodim>> findAll() {
        return ResponseEntity.ok(boshqaruvReepository.findAll());
    }


    public void updete(Long id, Xodim xodim1){
        Xodim xodim=boshqaruvReepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + id));
        xodim.setId(id);
        xodim.setAdress(xodim1.getAdress());
        xodim.setMonthlysalary(xodim1.getMonthlysalary());
        xodim.setPasport(xodim.getPasport());
        xodim.setLavozim(xodim1.getLavozim());
         boshqaruvReepository.save(xodim);
    }
    public void delete(Long id) {
        boshqaruvReepository.deleteById(id);
    }







}
