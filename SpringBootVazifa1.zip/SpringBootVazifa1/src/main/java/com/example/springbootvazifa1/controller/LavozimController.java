package com.example.springbootvazifa1.controller;

import com.example.springbootvazifa1.entity.Lavozim;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/test")
@CrossOrigin(value = "*")
public class LavozimController {

    @GetMapping("/direktor")
    public Lavozim get1() {
        return Lavozim.builder().id(1L).name("Direktor").build();
    }
    @GetMapping("/bo'limboshlig'i")
    public Lavozim get2() {
        return Lavozim.builder().id(1L).name("bo'limboshlig'i").build();
    }
    @GetMapping("/xodim")
    public Lavozim get3(){
        return Lavozim.builder().id(2L).name("xodim").build();
    }

}
