package com.example.springbootvazifa1.service;

import com.example.springbootvazifa1.entity.Pasport;
import com.example.springbootvazifa1.repository.PasportRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PasportService {
    private final PasportRepository pasportRepository;

    public Pasport addPasport(Pasport pasport){
       return pasportRepository.save(pasport);
    }
   public Pasport createPasport(Pasport pasport){
       return pasportRepository.save(pasport);
   }




}
