package com.example.springbootvazifa1.controller;

import com.example.springbootvazifa1.entity.Xodim;
import com.example.springbootvazifa1.service.BoshqaruvService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class BoshqaruvController {
    private final BoshqaruvService boshqaruvService;


    public BoshqaruvController(BoshqaruvService boshqaruvService) {
        this.boshqaruvService = boshqaruvService;
    }

    @PostMapping("/save")
    public ResponseEntity save(@RequestBody Xodim xodim){
        Xodim result=boshqaruvService.save(xodim);
        return  ResponseEntity.ok(result);
    }
    @GetMapping("/getby/{id}")
    public ResponseEntity<Xodim> findById(@RequestParam Long id){
        return boshqaruvService.findById(id);
    }
    @GetMapping("/finAll")
    public ResponseEntity<List<Xodim>> findAll(){
        return boshqaruvService.findAll();
    }
    @PutMapping
    public void updete(@RequestParam Long id, @RequestBody Xodim xodim){
        boshqaruvService.updete(id,xodim);
        System.out.println("malumot o'zgartirildi");
    }
    @DeleteMapping("/delete")
    public void delete(@RequestParam Long id){
        boshqaruvService.delete(id);
        System.out.println("malumot o'chirildi");
    }
}
