package com.example.springbootvazifa1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootVazifa1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootVazifa1Application.class, args);
	}

}
