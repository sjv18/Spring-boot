package com.example.springbootvazifa1.controller;

import com.example.springbootvazifa1.entity.Pasport;
import com.example.springbootvazifa1.service.PasportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PasportController {
    private final PasportService pasportService;

    public PasportController(PasportService pasportService) {
        this.pasportService = pasportService;
    }

    @PostMapping("/savepasport")
    public ResponseEntity createPasport(@RequestBody Pasport pasport){
        Pasport result=pasportService.createPasport(pasport);
        return ResponseEntity.ok(result);
    }
}
